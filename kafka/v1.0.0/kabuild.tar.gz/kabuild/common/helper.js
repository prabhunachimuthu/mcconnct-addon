﻿'use strict';

module.exports = {
    sortStringsByProperty: function (obj, propertyName, caseSensitive, orderBy) {
        var isAscending = orderBy || true;
        var property = propertyName;
        obj.sort(function (a, b) {
            var sortStatus = 0;
            var x = (isAscending ? a : b);
            var y = (isAscending ? b : a)

            if (caseSensitive) {
                if (x[property] < y[property]) {
                    sortStatus = -1;
                } else if (x[property] > y[property]) {
                    sortStatus = 1;
                }
            }
            else if (x[property] && y[property]) {
                if (x[property].toLowerCase() < y[property].toLowerCase()) {
                    sortStatus = -1;
                } else if (x[property].toLowerCase() > y[property].toLowerCase()) {
                    sortStatus = 1;
                }
            }

            return sortStatus;
        });
    },
    sortNumbersByProperty: function (obj, propertyName, orderBy) {
        var isAscending = orderBy || true;
        var property = propertyName;

        obj.sort(function (a, b) {
            var sortStatus = 0;
            var x = (isAscending ? a : b);
            var y = (isAscending ? b : a)

            if (x[property] < y[property]) {
                sortStatus = -1;
            }
            else if (x[property] > y[property]) {
                sortStatus = 1;
            }

            return sortStatus;
        });
    }
};