﻿'use strict';

var Kafka = require('no-kafka');

Kafka.setConsumerConfig = function (kafkaConfig) {
    // Check that required Kafka Config are defined
    var cert = kafkaConfig.syncDefaultClientCert;
    var key = kafkaConfig.syncDefaultClientCertKey;
    var url = kafkaConfig.syncDefaultKafkaUrl;
    if (!cert) throw new Error('KAFKA_CLIENT_CERT must be defined.');
    if (!key) throw new Error('KAFKA_CLIENT_CERT_KEY must be defined.');
    if (!url) throw new Error('KAFKA_URL must be defined.');

    // Configure consumer client
    var consumer = new Kafka.SimpleConsumer({
        clientId: 'softtrends-node-kafka',
        idleTimeout: 500,
        maxWaitTime: 10000,
        asyncCompression: true,
        reconnectionDelay: { max: 2000 },
        retries: { attempts: 0 },
        connectionString: url.replace(/\+ssl/g, ''),
        ssl: {
            certFile: cert,
            keyFile: key
        }
    });
    return consumer;
}

Kafka.setProducerConfig = function (kafkaConfig) {
    // Check that required Kafka Config are defined
    var cert = kafkaConfig.syncDefaultClientCert
    var key = kafkaConfig.syncDefaultClientCertKey
    var url = kafkaConfig.syncDefaultKafkaUrl
    if (!cert) throw new Error('KAFKA_CLIENT_CERT must be defined.');
    if (!key) throw new Error('KAFKA_CLIENT_CERT_KEY must be defined.');
    if (!url) throw new Error('KAFKA_URL must be defined.');

    // Configure producer client
    var producer = new Kafka.Producer({
        clientId: 'softtrends-node-kafka',
        asyncCompression: true,
        connectionString: url.replace(/\+ssl/g, ''),
        codec: Kafka.COMPRESSION_SNAPPY,
        ssl: {
            certFile: cert,
            keyFile: key
        }
    });
    return producer;
}

module.exports = Kafka;
