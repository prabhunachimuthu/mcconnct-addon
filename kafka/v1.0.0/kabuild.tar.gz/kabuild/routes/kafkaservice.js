﻿'use strict';

var Promise = require('bluebird');
var JSONbig = require('json-bigint');
var should = require('should');
var express = require('express');
var router = express.Router();
var Kafka = require(appRoot + 'kafka_config/config');
var helper = require(appRoot + 'common/helper');

function totalPartitions(consumer, topic) {
    var totPartitions = 0;
    try {
        var currentTopic = consumer.client.topicMetadata[topic];
        var keys = Object.keys(currentTopic);
        //totPartitions=currentTopic[keys[keys.length-1]].partitionId;
        totPartitions = (parseInt(keys[keys.length - 1], 10) + 1);
    }
    catch (e) {
        console.log(e);
    }

    return totPartitions;
}

function getOffsetInfo(consumer, topic) {
    var offsetInfo = {};
    offsetInfo.totalOffset = 0;
    offsetInfo.offsets = [];

    try {
        if (consumer.subscriptions) {
            var subscriptions = consumer.subscriptions;
            var keys = Object.keys(subscriptions).filter(function (key) { if (key.indexOf(topic) != -1) return key; });
            //console.log(keys);
            var offset = 0;
            for (var key in keys) {
                offset = parseInt(subscriptions[keys[key]].offset, 10);
                offsetInfo.offsets.push({ partition: subscriptions[keys[key]].partition, offset: offset });
                offsetInfo.totalOffset += offset > 0 ? (offset + 1) : 0;
            }
            if (offsetInfo.offsets.length > 0) {
                helper.sortNumbersByProperty(offsetInfo.offsets, "partition", true);
                //console.log(offsetInfo.offsets);
            }
        }
    }
    catch (e) {
        console.log(e);
    }

    return offsetInfo;
}

router.post('/getkafkatopics', function (req, res) {
    try {
        var kafkaConfig = req.body.kafkaConfig;
        //console.log(kafkaConfig);
        var consumer = Kafka.setConsumerConfig(kafkaConfig);
        //console.log(consumer);
        consumer.init().then(function () {
            var topicMetadata = consumer.client.topicMetadata;
            var keys = Object.keys(topicMetadata);
            //console.log(keys);
            //consumer.end();
            res.json({ topics: keys });
        }).catch(function (err) {
            console.log("getkafkatopics error: " + err);
            res.json({ topics: [] });
        });

    } catch (err) {
        console.log("getkafkatopics error: " + err);
        res.json({ topics: [] });
    }
});

router.post('/gettotalcount/:topic/', function (req, res) {
    try {
        console.log("Request messagescount for topic: " + req.params.topic);
        var kafkaConfig = req.body.kafkaConfig;
        var consumer = Kafka.setConsumerConfig(kafkaConfig);
        //console.log(consumer);
        consumer.init().then(function () {
            //console.log(consumer);
            //Kafka.LATEST_OFFSET
            consumer.subscribe(req.params.topic, { time: Kafka.LATEST_OFFSET, maxBytes: 1048576 }, function (messageSet, topic, partition) {
                console.log(messageSet[messageSet.length - 1].message.value.toString('utf8'));
                consumer.unsubscribe(req.params.topic);
                //res.json({MessageCount: messageSet.length});
            }).then(function (result) {
                console.log(consumer.subscriptions);
                var totPartitions = totalPartitions(consumer, req.params.topic);
                var offsetInfo = getOffsetInfo(consumer, req.params.topic);
                //consumer.end();
                res.json({ topic: req.params.topic, partitions: totPartitions, messages: offsetInfo.totalOffset, offsets: offsetInfo.offsets });

            }).catch(function (err) {
                console.log("gettotalcount error: " + err);
                //consumer.end();
                res.json({ topic: req.params.topic, partitions: 0, messages: 0, offsets: [] });
            })
        }).catch(function (err) {
            console.log("gettotalcount error: " + err);
            res.json({ topic: req.params.topic, partitions: 0, messages: 0, offsets: [] });
        });

    } catch (err) {
        console.log("gettotalcount error: " + err);
        res.json({ topic: req.params.topic, partitions: 0, messages: 0, offsets: [] });
    }
});

router.post('/getkafkamessages/:topic/:partition/:offset', function (req, res) {
    try {
        var limitOffset = 100;
        if (req.query.limit)
            limitOffset = req.query.limit;
        var kafkaConfig = req.body.kafkaConfig;
        var consumer = Kafka.setConsumerConfig(kafkaConfig);
        //console.log(consumer);

        consumer.init().then(function () {
            var reqOffset = parseInt(req.params.offset, 10);
            var reqPartition = parseInt(req.params.partition, 10);
            console.log("consumer subscribe: " + req.params.topic + " partition: " + reqPartition + " Offset: " + reqOffset);

            consumer.offset(req.params.topic, reqPartition).then(function (offset) {
                console.log('offset:' + offset);
                var resData = {};
                resData.maxOffset = offset;
                resData.topic = req.params.topic;
                resData.partition = reqPartition;
                resData.messages = [];

		//time: Kafka.LATEST_OFFSET, recoveryOffset: Kafka.LATEST_OFFSET,
                //    startingOffset: Kafka.LATEST_OFFSET
                consumer.subscribe(req.params.topic, reqPartition, { offset: reqOffset, maxBytes: 2000000 }, function (messageSet, topic, partition) {
                    if (res.headersSent) {
                        return;
                    }
                    console.log("read data"+messageSet.length);
                    resData.messages = [];
                    for (var i = 0; messageSet && i < messageSet.length; i++) {
                        try {
			    if(messageSet[i].offset>=reqOffset){
                            var m = messageSet[i];
                            console.log(m);
                            if (m.message.value) {
                                var msg = m.message.value.toString('utf8');
                                msg = msg.replace(/\"/g, "\"").replace(/'{/g, "{").replace(/}'/g, "}")
                                resData.messages.push(JSON.parse(msg));
                                //consumer.commitOffset({ topic: topic, partition: partition, offset: m.offset, metadata: 'optional' });
                            }
			  }
                        } catch (e) {
                            console.log("not JSON");
                        }

                        if (resData.messages.length == limitOffset) {
                            break;
                        }
                    }

                    consumer.unsubscribe(req.params.topic);
                    //consumer.end();
                    res.json(resData);

                }).then(function () {
                    //console.log(consumer.subscriptions);
                    var keys = Object.keys(consumer.subscriptions);
                    console.log(consumer.subscriptions[keys[0]]);
                    consumer.subscriptions[keys[0]].offset.should.be.belowOrEqual(offset - 1);
                }).catch(function (err) {
                    console.log('consumer.subscribe() error: ' + err);
                    //consumer.end();
                    res.json(null);
                });

            }).catch(function (err) {
                console.log('consumer.offset() error: ' + err);
                //consumer.end();
                res.json(null);
            });

        }).catch(function (err) {
            console.log('consumer.init() error: ' + err);
            res.json(null);
        });
    } catch (err) {
        console.log("getkafkamessages error: " + err);
        res.json(null);
    }
});

router.post('/postkafkamessages', function (req, res) {
    var kafkaConfig = req.body.kafkaConfig;
    var messages = req.body.messages;
    var topic = req.query.topic;
    console.log("topic: " + topic);
    console.log("messages: " + messages.length);
    if (topic && messages && messages.length > 0) {
        try {
		var data = [];
		for (var i = 0; i < messages.length; i++) {
		    var msg = JSONbig.stringify(messages[i]);
		    if (msg) {
			msg = msg.replace(/\"/g, "\"");
		    }
		    data.push({ topic: topic, message: { value: msg } });
		}
            const producer = Kafka.setProducerConfig(kafkaConfig);
            //console.log(producer);
            producer.init().then(function () {
                var dataArr = [], size = 10;
                while (data.length > 0){ 
			dataArr.push(data.splice(0, size));
		}
                while (dataArr.length > 0) {
                        if (dataArr[0].length > 0) {
                            producer.send(dataArr[0], { batch: { size: 20480, maxWait: 3000 } }).then(function (result) {
                                //console.log("messages posted:"+ JSON.stringify(result));
                                console.log(result.length + " messages posted.");
                            });
                        }
                        dataArr.splice(0, 1);
                }

                //producer.end();
                res.writeHead(200, { 'Content-Type': 'text/plain' });
                res.write("Messages posted successfully");
                res.end();
            });

        } catch (err) {
            console.log("postkafkamessages error: " + err);
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.write("internal server error");
            res.end();
        }
    }
    else {
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.write("messages was empty");
        res.end();
    }
});

module.exports = router;
